DROP TABLE clearData;
  
CREATE TABLE clearData (
    playerName VARCHAR2(20)
  , stageNum NUMBER
  , clearTime VARCHAR2(20)
  , clearWhen DATE
);